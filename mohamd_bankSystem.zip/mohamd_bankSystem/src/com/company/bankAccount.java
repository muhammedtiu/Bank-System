package com.company;

public class bankAccount {
    int id;
    String name;
    int cridit;
    int active;

    public bankAccount() {
    }

    public bankAccount(int id, String name, int cridit, int active) {
        this.id = id;
        this.name = name;
        this.cridit = cridit;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCridit() {
        return cridit;
    }

    public void setCridit(int cridit) {
        this.cridit = cridit;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public boolean getStatas(int cridit) {
      if(cridit>10)return true;
      return false;
    }
}
