package com.company;

public class manger extends person {
    int salayr;
    boolean accses;
    String branch;


    public manger(int age, String name, int id, String nationality, String gender, String educational, int salayr, boolean accses, String branch) {
        super(age, name, id, nationality, gender, educational);
        this.salayr = salayr;
        this.accses = accses;
        this.branch = branch;
    }

    public manger() {
    }


    public int getSalayr() {
        return salayr;
    }

    public void setSalayr(int salayr) {
        this.salayr = salayr;
    }

    public boolean isAccses() {
        return accses;
    }

    public void setAccses(boolean accses) {
        this.accses = accses;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }
}
