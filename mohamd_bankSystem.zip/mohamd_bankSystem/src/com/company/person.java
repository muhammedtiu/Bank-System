package com.company;

public class person {
    int age ;
    String name;
    int id;
    String nationality;
    String gender;
    String Educational;

    public person() {
    }

    public person(int age, String name, int id, String nationality, String gender, String educational) {
        this.age = age;
        this.name = name;
        this.id = id;
        this.nationality = nationality;
        this.gender = gender;
        Educational = educational;
    }


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean grownup(int age) {
      if(age>18)return true;
       return false;

    }

    public boolean isiraqi(String contry) {
        if(contry.equals("iraq"))return true;
        return false;

    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEducational() {
        return Educational;
    }

    public void setEducational(String educational) {
        Educational = educational;
    }
}
