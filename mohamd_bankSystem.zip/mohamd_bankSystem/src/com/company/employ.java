package com.company;

public class employ extends person {
    int sylary;

    public employ() {
    }

    public employ(int age, String name, int id, String nationality, String gender, String educational, int sylary) {
        super(age, name, id, nationality, gender, educational);
        this.sylary = sylary;
    }

    public int getSylary() {
        return sylary;
    }

    public void setSylary(int sylary) {
        this.sylary = sylary;
    }
}
