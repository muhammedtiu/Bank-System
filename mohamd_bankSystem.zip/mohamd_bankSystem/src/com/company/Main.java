package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
   public String  faccount, fmanger,femploy;
    public static void main(String[] args) {
while (true) {
    new Main();
}

    }
    public Main() {
        faccount="account.txt";
        fmanger="manger.txt";
        femploy="employ.txt";
        creatfile(faccount);
        creatfile(fmanger);
        creatfile(femploy);
        System.out.println(" \n  mohamed bank system ");

        System.out.println("\n to creat account press (1) ");
        System.out.println("\n to creat employ  press (2) ");
        System.out.println("\n to creat manger  press (3) ");
        System.out.println("\n to view all account press  (4)  ");
        System.out.println("\n to view all employ press  (5)  ");
        System.out.println("\n to view all manger press  (6)  ");
        System.out.println("\n else to exit  ");
        System.out.println("\n|   pleas enter number ");
        Scanner scanner = new Scanner(System.in);
        int select = scanner.nextInt();

        if(select==1){

          bankAccount account = new bankAccount();
            System.out.println("\n|   pleas enter account name ");
            account.setName(scanner.next());
            System.out.println("\n|   pleas enter account id - number only ");
            account.setId(scanner.nextInt());
            System.out.println("\n|   pleas enter account Cridit -number only  ");
            account.setCridit(scanner.nextInt());
            System.out.println("\n|   pleas enter account Active -0 or 1 ");
            account.setActive(scanner.nextInt());
            WriteToFile(account);
        }

        else  if(select==2){

            employ employ = new employ();
            System.out.println("\n|   pleas enter employ name ");
            employ.setName(scanner.next());
            System.out.println("\n|   pleas enter employ id - number only ");
            employ.setId(scanner.nextInt());
            System.out.println("\n|   pleas enter employ Sylary -number only  ");
            employ.setSylary(scanner.nextInt());
            System.out.println("\n|   pleas enter Educational   ");
            employ.setEducational(scanner.next());
            System.out.println("\n|   pleas enter employ Gender  ");
            employ.setGender(scanner.next());
            System.out.println("\n|   pleas enter employ Nationality  ");
            employ.setNationality(scanner.next());


            WriteToFile(employ);

        }

        else  if(select==3){

            manger manger = new manger();
            System.out.println("\n|   pleas enter manger name ");
            manger.setName(scanner.next());
            System.out.println("\n|   pleas enter manger id - number only ");
            manger.setId(scanner.nextInt());
            System.out.println("\n|   pleas enter manger Salayr -number only  ");
            manger.setSalayr(scanner.nextInt());
            System.out.println("\n|   pleas enter manger Age");
            manger.setAge(scanner.nextInt());
            System.out.println("\n|   pleas enter manger Gender ");
            manger.setGender(scanner.next());




            WriteToFile(manger);

        }
        else  if(select==4){

            Readfile(faccount);

        }
        else  if(select==5){


            Readfile(femploy);
        }
        else  if(select==6){

            Readfile(fmanger);

        }
        else{System.exit(0);}
    }





    public void creatfile(String filename) {

        try {
            File myObj = new File(filename);
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }

          public void WriteToFile(bankAccount account ) {

            try {
                FileWriter myWriter = new FileWriter(faccount);
                myWriter.write(account.getName() + " "+ account.getId()+" "+account.getCridit());

                myWriter.close();

                System.out.println("Successfully create the account.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }

    public void WriteToFile(employ employ ) {

        try {
            FileWriter myWriter = new FileWriter(femploy);
            myWriter.write(employ.getName()+" "+
                            employ.getId()+" "+
                            employ.getId()+" "+
                    employ.getSylary()+" "+
                    employ.getAge()+" "+
                    employ.getEducational()+" "+
                    employ.getNationality()+" "+
                    employ.getGender()+"");


            myWriter.close();

            System.out.println("Successfully create the account.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public void WriteToFile(manger manger ) {

        try {
            FileWriter myWriter = new FileWriter(fmanger);
            myWriter.write(manger.getName()+" "+
            manger.getId()+" "+
           manger.getSalayr()+"");
            myWriter.close();

            System.out.println("Successfully create the account.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }



    public void Readfile(String filename){

        try {
            File myObj = new File(filename);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }


    }



