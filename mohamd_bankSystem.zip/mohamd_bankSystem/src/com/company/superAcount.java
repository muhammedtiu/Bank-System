package com.company;

public class superAcount extends bankAccount{
    public superAcount(int id, String name, int cridit, int active) {
        super(id, name, cridit, active);
    }

    public superAcount() {
    }

    @Override
    public boolean getStatas(int cridit) {
        if(cridit>0)return true;
        return false;
    }
}
